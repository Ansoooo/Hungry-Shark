Control the Shark (blue circle) using right mouse button to swim towards that place.

Eating green fish will make the shark feel full.

Eating purple fish will hurt the shark's stomach.